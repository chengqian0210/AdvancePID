wc=10;
F1 = 2*wc;
F2 = wc^2;
alpha0 = 0;
Kp = 100;
Kd = 100;
Ki = 100;
namuta = 50;